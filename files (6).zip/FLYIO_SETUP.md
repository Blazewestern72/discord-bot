# 🚀 Fly.io Setup Guide - FREE 24/7 Discord Bot

## ✅ Why Fly.io?
- ✅ **FREE forever** - 3 free VMs (micro)
- ✅ **No credit card** required for free tier
- ✅ **Never sleeps** - true 24/7
- ✅ **Fast deployment** - 5-10 minutes
- ✅ **Global network** - choose your region
- ✅ **Professional platform**

---

## 📋 What You'll Need
1. Computer with terminal/command prompt
2. Your bot files (I'll provide)
3. Discord bot token
4. 10 minutes of your time

---

## 🎯 Complete Setup Guide

### Method 1: Command Line (Recommended - Easiest!)

This is the quickest way - just copy and paste commands!

---

### **STEP 1: Install Fly.io CLI**

**On Windows (Command Prompt):**
```cmd
powershell -Command "iwr https://fly.io/install.ps1 -useb | iex"
```

**On Mac/Linux:**
```bash
curl -L https://fly.io/install.sh | sh
```

Wait for it to install (takes 30 seconds).

---

### **STEP 2: Sign Up for Fly.io**

In your terminal/command prompt:

```bash
flyctl auth signup
```

This will:
1. Open your browser
2. Sign up with email or GitHub
3. **No credit card needed!**
4. Verify your email

---

### **STEP 3: Login**

After signing up:

```bash
flyctl auth login
```

Browser opens → Click "Authorize" → Done!

---

### **STEP 4: Prepare Your Files**

Create a folder on your Desktop called `dropshipping-bot`

Put these 3 files in it:

#### File 1: `bot.py`
(Use the bot.py file I provided earlier)

#### File 2: `requirements.txt`
```
discord.py>=2.3.0
```

#### File 3: `Dockerfile`
```dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY bot.py .

CMD ["python", "bot.py"]
```

---

### **STEP 5: Navigate to Your Folder**

Open Command Prompt/Terminal and go to your folder:

**Windows:**
```cmd
cd Desktop\dropshipping-bot
```

**Mac/Linux:**
```bash
cd ~/Desktop/dropshipping-bot
```

---

### **STEP 6: Launch Your App**

```bash
flyctl launch
```

You'll be asked some questions:

**Question 1:** "Choose an app name"
- Type: `dropshipping-bot-yourname` (or press Enter for random name)

**Question 2:** "Choose a region"
- Pick closest to you (or just press Enter for default)

**Question 3:** "Would you like to set up a Postgresql database?"
- Type: **n** (no)

**Question 4:** "Would you like to set up an Upstash Redis database?"
- Type: **n** (no)

**Question 5:** "Would you like to deploy now?"
- Type: **n** (no - we need to add the token first!)

This creates a `fly.toml` file - you're almost done!

---

### **STEP 7: Add Your Discord Bot Token (IMPORTANT!)**

```bash
flyctl secrets set DISCORD_BOT_TOKEN=your_actual_token_here
```

Replace `your_actual_token_here` with your real Discord bot token!

Example:
```bash
flyctl secrets set DISCORD_BOT_TOKEN=MTIzNDU2Nzg5MDEyMzQ1Njc4OQ.AbCdEf.1234567890abcdefghijklmnop
```

---

### **STEP 8: Deploy Your Bot!**

```bash
flyctl deploy
```

Wait 2-3 minutes while it:
- Builds your bot
- Uploads to Fly.io
- Starts running

You'll see lots of text - this is normal!

---

### **STEP 9: Check if Bot is Running**

```bash
flyctl status
```

Should show: **Status = running** ✅

Check Discord - your bot should be **online** (green)!

Type `/help` in Discord to test!

---

## 🎉 YOU'RE DONE!

Your bot is now running 24/7 for FREE on Fly.io!

---

## 📊 Managing Your Bot

### View Logs:
```bash
flyctl logs
```

### Restart Bot:
```bash
flyctl apps restart dropshipping-bot
```

### Stop Bot:
```bash
flyctl scale count 0
```

### Start Bot Again:
```bash
flyctl scale count 1
```

### Check Status:
```bash
flyctl status
```

### View Dashboard:
Go to: https://fly.io/dashboard

---

## 🔄 Updating Your Bot

### When you change code:

1. Edit your `bot.py` file
2. Run:
```bash
flyctl deploy
```

That's it! Fly.io rebuilds and redeploys automatically!

---

## 💾 Important Notes

### Free Tier Limits:
- ✅ 3 free VMs (shared-cpu-1x)
- ✅ 256MB RAM each
- ✅ 3GB persistent storage
- ✅ More than enough for Discord bots!

### Data Persistence:
Like other platforms, files don't persist between deploys.

**Want database support?** Let me know and I'll add it!

---

## 🔧 Troubleshooting

### "flyctl: command not found"
**Fix:** 
- Close and reopen your terminal
- On Windows, restart Command Prompt
- Try: `fly` instead of `flyctl`

### "Error: no organization selected"
**Fix:**
```bash
flyctl orgs list
flyctl auth login
```

### Bot shows as "deployed" but offline in Discord:
**Fix:**
- Check logs: `flyctl logs`
- Verify token: `flyctl secrets list`
- Make sure Discord intents are enabled

### "Insufficient resources"
**Fix:**
- You might have too many apps
- Delete unused apps: `flyctl apps destroy app-name`

### Bot crashes immediately:
**Fix:**
- Check logs: `flyctl logs`
- Probably wrong token or missing intents

---

## 💡 Pro Tips

### Change Region (if bot is slow):
```bash
flyctl regions list
flyctl regions set iad  # US East
```

### Scale Resources (if needed):
```bash
flyctl scale vm shared-cpu-1x --memory 512
```

### Auto-Scale (advanced):
```bash
flyctl scale count 1
```

---

## 🆚 Fly.io vs Others

| Feature | Fly.io | Replit | Northflank |
|---------|--------|--------|------------|
| **Setup** | Command line | Web interface | Web interface |
| **Speed** | Medium | Fast | Medium |
| **Free?** | ✅ Forever | ✅ Forever | ✅ Forever |
| **Sleeps?** | ❌ No | ⚠️ Yes* | ❌ No |
| **RAM** | 256MB | 512MB | 512MB |

---

## 📱 Quick Command Reference

```bash
# Deploy bot
flyctl deploy

# Check status
flyctl status

# View logs
flyctl logs

# Restart
flyctl apps restart

# Add secret
flyctl secrets set KEY=value

# List secrets
flyctl secrets list

# Open dashboard
flyctl dashboard
```

---

## 🎯 What If Commands Don't Work?

### Alternative Method: Use Fly.io Dashboard

1. Go to **https://fly.io/dashboard**
2. Click **"New app"**
3. Choose **"Deploy from GitHub"**
4. Connect your GitHub repo
5. Add environment variable: `DISCORD_BOT_TOKEN`
6. Deploy!

This is more visual and might be easier if command line is confusing!

---

## ✅ Checklist

Before deploying, make sure:
- [ ] Fly CLI installed
- [ ] Logged into Fly.io account
- [ ] All 3 files in folder (bot.py, requirements.txt, Dockerfile)
- [ ] Discord bot token ready
- [ ] Both intents enabled in Discord Developer Portal
- [ ] In correct folder in terminal

---

## 🆘 Still Need Help?

**Common issues:**

**Q: Don't understand command line?**
A: Use Replit instead - it's all web-based!

**Q: "flyctl not found" error?**
A: Restart terminal/command prompt after installing

**Q: How do I get to command prompt?**
A: Windows Key + R, type `cmd`, press Enter

**Q: Bot deploys but stays offline?**
A: Check token is correct with `flyctl secrets list`

---

## 🎉 You're All Set!

Your bot is now:
- ✅ Running 24/7 FREE on Fly.io
- ✅ Professional infrastructure  
- ✅ Global edge network
- ✅ Easy to update
- ✅ Never sleeps

**Start managing your dropshipping business!** 🚀

---

## 💬 Need More Help?

Tell me:
1. What step you're on
2. What error you see
3. What platform you're using (Windows/Mac)

I'll help you fix it! 💪
